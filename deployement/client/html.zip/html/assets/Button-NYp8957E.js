import{j as r}from"./index-yo_zDtYs.js";const o=({title:t,style:e})=>r.jsx("button",{className:`p-2 bg-darkGreen text-white  uppercase font-semibold ${e}`,children:t});export{o as B};
