const o="/assets/logo-CMVyntkp.svg";export{o as l};
