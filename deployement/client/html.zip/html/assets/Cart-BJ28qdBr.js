import{j as r}from"./index-yo_zDtYs.js";const s=()=>r.jsx("div",{children:"Cart"});export{s as default};
