import{j as t,O as o}from"./index-yo_zDtYs.js";import{I as s}from"./index-BrqMfhrt.js";const m=()=>t.jsxs(t.Fragment,{children:[t.jsx(s,{position:"top-right"}),t.jsx(o,{})]});export{m as default};
