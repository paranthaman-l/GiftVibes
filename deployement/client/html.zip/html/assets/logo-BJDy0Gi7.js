const o="/assets/logo-DnTxtvax.svg";export{o as l};
